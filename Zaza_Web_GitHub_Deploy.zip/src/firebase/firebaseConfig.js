const firebaseConfig = {
  apiKey: "AIzaSyDov8anmioSv-Rgptgdso1Hhc0NStWt0",
  authDomain: "zaza-launch.firebaseapp.com",
  projectId: "zaza-launch",
  storageBucket: "zaza-launch.appspot.com",
  messagingSenderId: "699651890444",
  appId: "1:699651890444:web:f38f421fa5fd818afdad55"
};

export default firebaseConfig;
